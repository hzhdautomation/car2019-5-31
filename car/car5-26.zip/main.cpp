#include <conio.h> 
#include <iostream> 

#include "Drawing.h"


using namespace std; 
int main() {
	char a[][11] = { { "----45----" },{ "---ABCD---" },{ "---EFG----" },{ "----------" } };
	image img;
	img.width = 10;
	img.height = 4;
	img.data = a[0];

	Drawing screen;
	int i = 0;
	//while (true) {
	screen.setImage(5, 116, 6, 3, img);
	screen.flushScreen();
	Sleep(500);
	//keyboard
	if (_kbhit()) {
		char ch = _getch();
		cout << ch;
		if (ch == 27) {//ESC
			//break;
		}
	}
	//}

	system("pause");
	return 0;
}












